import CoolProp.CoolProp as CP
import pandas as pd
import numpy as np

def generate_fluid_dataset(fluid_name, T_range, P_range):
    data = []
    print(f"Generating data for {fluid_name}")
    for T in T_range:
        for p in P_range:
            density = CP.PropsSI('D', 'T', T, 'P', p, fluid_name)
            data.append([T, p, density])
    
    #DataFrame
    df = pd.DataFrame(data, columns=['Temperature (K)', 'Pressure (Pa)', 'Density (kg/m^3)'])
    
    # Export to CSV
    filename = f"{fluid_name}_benchmark_data.csv"
    df.to_csv(filename, index=False)
    print(f"Successfully saved to {filename}")

# Define Grids
# Methane Grid
methane_T = np.linspace(200, 400, 20) # 20 points
methane_P = np.linspace(1e5, 1e6, 10) # 10 points

# R134a Grid
r134a_T = np.linspace(380, 500, 20)
r134a_P = np.linspace(1e5, 2e6, 10)

# Run Generation
generate_fluid_dataset('Methane', methane_T, methane_P)
generate_fluid_dataset('R134a', r134a_T, r134a_P)